package com.bacode.hi.dao;

import java.util.List;

import com.bacode.hi.vo.TestVO;

public interface ItestDao {
	
	TestVO getTestVO();

	List<TestVO> getTestVoList();
	
	
	
	
}
